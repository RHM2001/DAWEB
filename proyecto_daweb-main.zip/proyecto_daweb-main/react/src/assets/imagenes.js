import cocinero from './img/cocinero.png';
import perfil from './img/perfil.png'

export default {
    "img1": cocinero,
    "img2": perfil
}