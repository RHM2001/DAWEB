import React, {useState} from 'react'

export default function Footer() {

  return (
    <footer className="footer">
      <p className="footer-text">© 2023 Desarrollo de aplicaciones web. Raúl Hernández Martínez y Silvia Pérez Ruiz.</p>
    </footer>
  )
}
